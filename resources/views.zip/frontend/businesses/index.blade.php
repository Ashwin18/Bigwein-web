@extends('frontend.layouts.app')
@section('title','Business For Sale — BigWein')
@section('meta_desc','Browse verified businesses for sale across India. Restaurants, retail stores, franchises and more. Zero brokerage.')

@section('content')
@php $currency = $s['currency_symbol'] ?? '₹'; @endphp

{{-- Page Hero --}}
<div style="background:linear-gradient(135deg,#0a0a14 0%,#1a1025 100%);padding:50px 0 40px;position:relative;overflow:hidden;">
  <div style="position:absolute;inset:0;background:url('data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22100%22><circle cx=%2250%22 cy=%2250%22 r=%2230%22 fill=%22none%22 stroke=%22rgba(229,52,58,.08)%22 stroke-width=%221%22/></svg>') repeat;"></div>
  <div class="container" style="position:relative;">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
      <a href="/" style="color:rgba(255,255,255,.5);font-size:13px;text-decoration:none;">Home</a>
      <span style="color:rgba(255,255,255,.3);font-size:13px;">›</span>
      <span style="color:#fff;font-size:13px;font-weight:600;">Business For Sale</span>
    </div>
    <h1 style="color:#fff;font-size:clamp(24px,4vw,36px);font-weight:800;margin:0 0 8px;">Business For Sale</h1>
    <p style="color:rgba(255,255,255,.65);font-size:15px;margin:0;">{{ $businesses->total() }} verified businesses listed · Zero brokerage</p>
  </div>
</div>

{{-- Filters --}}
<div style="background:#fff;border-bottom:1px solid #E2E8F0;position:sticky;top:0;z-index:100;">
  <div class="container" style="padding:14px 0;">
    <form method="GET" action="/businesses" style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;">
      <input type="text" name="city" value="{{ request('city') }}" placeholder="🏙️ City or location"
        style="border:1px solid #E2E8F0;border-radius:10px;padding:8px 14px;font-size:13px;outline:none;min-width:160px;"/>
      <select name="btype" style="border:1px solid #E2E8F0;border-radius:10px;padding:8px 14px;font-size:13px;outline:none;color:#374151;">
        <option value="">All Types</option>
        @foreach($btypes as $bt)
        <option value="{{ $bt }}" {{ request('btype')===$bt?'selected':'' }}>{{ $bt }}</option>
        @endforeach
      </select>
      <select name="price_max" style="border:1px solid #E2E8F0;border-radius:10px;padding:8px 14px;font-size:13px;outline:none;color:#374151;">
        <option value="">Any Budget</option>
        <option value="1000000"  {{ request('price_max')==='1000000'?'selected':'' }}>Under ₹10L</option>
        <option value="5000000"  {{ request('price_max')==='5000000'?'selected':'' }}>Under ₹50L</option>
        <option value="10000000" {{ request('price_max')==='10000000'?'selected':'' }}>Under ₹1Cr</option>
        <option value="50000000" {{ request('price_max')==='50000000'?'selected':'' }}>Under ₹5Cr</option>
      </select>
      <button type="submit" style="background:#E5343A;color:#fff;border:none;border-radius:10px;padding:8px 20px;font-size:13px;font-weight:700;cursor:pointer;">
        Search
      </button>
      @if(request()->anyFilled(['city','btype','price_max']))
      <a href="/businesses" style="color:#E5343A;font-size:13px;font-weight:600;text-decoration:none;">✕ Clear</a>
      @endif
    </form>
  </div>
</div>

{{-- Listings --}}
<section style="padding:40px 0;background:#F8FAFC;min-height:60vh;">
  <div class="container">
    @forelse($businesses as $biz)
    @php
      $meta   = json_decode($biz->business_meta ?? '{}', true) ?? [];
      $imgSrc = $biz->title_image ? url('images/property_title_img/'.$biz->title_image) : null;
      $priceF = $biz->price ? $currency.number_format($biz->price) : 'Price on Request';
    @endphp
    <div style="background:#fff;border:1px solid #E2E8F0;border-radius:16px;display:flex;gap:0;overflow:hidden;margin-bottom:16px;transition:box-shadow .2s;"
         onmouseover="this.style.boxShadow='0 8px 30px rgba(0,0,0,.1)'" onmouseout="this.style.boxShadow=''">
      {{-- Image --}}
      <div style="width:260px;flex-shrink:0;position:relative;">
        @if($imgSrc)
          <img src="{{ $imgSrc }}" style="width:100%;height:100%;min-height:180px;object-fit:cover;" onerror="this.style.display='none'"/>
        @else
          <div style="width:100%;height:100%;min-height:180px;background:linear-gradient(135deg,#F1F5F9,#E2E8F0);display:flex;align-items:center;justify-content:center;">
            <i class="fa-solid fa-store" style="font-size:40px;color:#CBD5E1;"></i>
          </div>
        @endif
        <div style="position:absolute;top:10px;left:10px;background:#E5343A;color:#fff;font-size:10px;font-weight:700;padding:3px 10px;border-radius:20px;text-transform:uppercase;">
          {{ $biz->business_type ?: 'Business' }}
        </div>
      </div>
      {{-- Details --}}
      <div style="padding:20px 24px;flex:1;display:flex;flex-direction:column;justify-content:space-between;">
        <div>
          <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:6px;">
            <h3 style="font-size:17px;font-weight:700;color:#0F172A;margin:0;line-height:1.3;">
              <a href="/business/{{ $biz->slug_id }}" style="text-decoration:none;color:inherit;">{{ $biz->title }}</a>
            </h3>
            <div style="font-size:18px;font-weight:800;color:#E5343A;white-space:nowrap;">{{ $priceF }}</div>
          </div>
          <div style="font-size:13px;color:#64748B;margin-bottom:10px;">
            <i class="fa-solid fa-location-dot" style="color:#E5343A;margin-right:4px;"></i>
            {{ implode(', ', array_filter([$biz->city, $biz->state])) ?: 'India' }}
          </div>
          <p style="font-size:13px;color:#475569;line-height:1.6;margin:0 0 12px;">
            {{ Str::limit($biz->description, 120) }}
          </p>
          {{-- Meta chips --}}
          <div style="display:flex;flex-wrap:wrap;gap:6px;">
            @if(!empty($meta['turnover']))
            <span style="background:#F0FDF4;color:#166534;border:1px solid #BBF7D0;font-size:11px;font-weight:600;padding:3px 10px;border-radius:20px;">
              <i class="fa-solid fa-chart-line fa-xs me-1"></i>Turnover: {{ $meta['turnover'] }}
            </span>
            @endif
            @if(!empty($meta['employees']))
            <span style="background:#EFF6FF;color:#1D4ED8;border:1px solid #BFDBFE;font-size:11px;font-weight:600;padding:3px 10px;border-radius:20px;">
              <i class="fa-solid fa-users fa-xs me-1"></i>{{ $meta['employees'] }} Employees
            </span>
            @endif
            @if(!empty($meta['established_year']))
            <span style="background:#FFF7ED;color:#C2410C;border:1px solid #FED7AA;font-size:11px;font-weight:600;padding:3px 10px;border-radius:20px;">
              <i class="fa-solid fa-calendar fa-xs me-1"></i>Est. {{ $meta['established_year'] }}
            </span>
            @endif
            @if($biz->reference_no)
            <span style="background:#F8FAFC;color:#64748B;border:1px solid #E2E8F0;font-size:11px;font-weight:600;padding:3px 10px;border-radius:20px;font-family:monospace;">
              # {{ $biz->reference_no }}
            </span>
            @endif
          </div>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-top:16px;padding-top:14px;border-top:1px solid #F1F5F9;">
          <span style="font-size:11px;color:#94A3B8;">{{ \Carbon\Carbon::parse($biz->created_at)->diffForHumans() }}</span>
          <div style="display:flex;gap:8px;">
            <button onclick="bwEnquire({{ $biz->id }}, '{{ addslashes($biz->title) }}')"
              style="background:#FFF1F3;color:#E5343A;border:1px solid #FECDD3;border-radius:8px;padding:7px 16px;font-size:12px;font-weight:700;cursor:pointer;">
              <i class="fa-regular fa-envelope me-1"></i> Enquire
            </button>
            <a href="/business/{{ $biz->slug_id }}"
              style="background:#E5343A;color:#fff;border-radius:8px;padding:7px 16px;font-size:12px;font-weight:700;text-decoration:none;display:inline-flex;align-items:center;">
              View Details →
            </a>
          </div>
        </div>
      </div>
    </div>
    @empty
    <div style="text-align:center;padding:80px 20px;background:#fff;border-radius:16px;">
      <i class="fa-solid fa-store" style="font-size:48px;color:#E2E8F0;display:block;margin-bottom:16px;"></i>
      <h3 style="color:#374151;margin-bottom:8px;">No businesses listed yet</h3>
      <p style="color:#94A3B8;margin-bottom:20px;">Be the first to list your business for sale.</p>
      <a href="/owner/post-business" style="background:#E5343A;color:#fff;border-radius:10px;padding:10px 24px;font-size:14px;font-weight:700;text-decoration:none;">+ List Your Business</a>
    </div>
    @endforelse

    {{-- Pagination --}}
    @if($businesses->hasPages())
    <div style="margin-top:24px;">{{ $businesses->links() }}</div>
    @endif
  </div>
</section>

{{-- Enquiry Modal --}}
<div id="bfsEnquiryModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;align-items:center;justify-content:center;">
  <div style="background:#fff;border-radius:20px;padding:28px;width:90%;max-width:420px;position:relative;">
    <button onclick="document.getElementById('bfsEnquiryModal').style.display='none'"
      style="position:absolute;top:14px;right:14px;background:none;border:none;font-size:20px;cursor:pointer;color:#94A3B8;">✕</button>
    <h4 style="font-size:16px;font-weight:800;margin:0 0 4px;color:#0F172A;">Send Enquiry</h4>
    <p id="bfsModalBizName" style="font-size:13px;color:#64748B;margin:0 0 16px;"></p>
    <input id="bfsName" type="text" placeholder="Your Name *" style="width:100%;border:1px solid #E2E8F0;border-radius:10px;padding:10px 14px;font-size:13px;outline:none;margin-bottom:10px;"/>
    <input id="bfsMobile" type="tel" placeholder="Mobile Number *" style="width:100%;border:1px solid #E2E8F0;border-radius:10px;padding:10px 14px;font-size:13px;outline:none;margin-bottom:10px;"/>
    <input id="bfsEmail" type="email" placeholder="Email (optional)" style="width:100%;border:1px solid #E2E8F0;border-radius:10px;padding:10px 14px;font-size:13px;outline:none;margin-bottom:10px;"/>
    <textarea id="bfsMsg" placeholder="Message (optional)" rows="3" style="width:100%;border:1px solid #E2E8F0;border-radius:10px;padding:10px 14px;font-size:13px;outline:none;resize:none;margin-bottom:14px;"></textarea>
    <button onclick="submitBfsEnquiry()" id="bfsSubmitBtn"
      style="width:100%;background:#E5343A;color:#fff;border:none;border-radius:10px;padding:12px;font-size:14px;font-weight:700;cursor:pointer;">
      Send Enquiry
    </button>
    <input type="hidden" id="bfsPropId" value=""/>
  </div>
</div>

@endsection
@section('js')
<script>
function bwEnquire(id, name) {
  document.getElementById('bfsPropId').value = id;
  document.getElementById('bfsModalBizName').textContent = name;
  document.getElementById('bfsEnquiryModal').style.display = 'flex';
}
async function submitBfsEnquiry() {
  var name = document.getElementById('bfsName').value.trim();
  var mob  = document.getElementById('bfsMobile').value.trim();
  if (!name || !mob) { alert('Name and mobile are required.'); return; }
  var btn = document.getElementById('bfsSubmitBtn');
  btn.textContent = 'Sending...'; btn.disabled = true;
  try {
    var res = await fetch('/business/enquiry', {
      method:'POST',
      headers:{'Content-Type':'application/json','X-CSRF-TOKEN':'{{ csrf_token() }}','Accept':'application/json'},
      body: JSON.stringify({
        property_id: document.getElementById('bfsPropId').value,
        name: name, mobile: mob,
        email: document.getElementById('bfsEmail').value,
        message: document.getElementById('bfsMsg').value
      })
    });
    var d = await res.json();
    if(d.success) {
      document.getElementById('bfsEnquiryModal').style.display='none';
      alert('Enquiry sent! The seller will contact you shortly.');
    }
  } catch(e) {}
  btn.textContent = 'Send Enquiry'; btn.disabled = false;
}
</script>
@endsection
