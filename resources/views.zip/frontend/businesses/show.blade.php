@extends('frontend.layouts.app')
@section('title', $business->title . ' — Business For Sale | BigWein')

@section('content')
@php $currency = $s['currency_symbol'] ?? '₹'; $priceF = $business->price ? $currency.number_format($business->price) : 'Price on Request'; @endphp

<div class="container" style="padding:32px 0 60px;">
  {{-- Breadcrumb --}}
  <div style="font-size:13px;color:#64748B;margin-bottom:20px;">
    <a href="/" style="color:#64748B;text-decoration:none;">Home</a> ›
    <a href="/businesses" style="color:#64748B;text-decoration:none;">Business For Sale</a> ›
    <span style="color:#0F172A;font-weight:600;">{{ Str::limit($business->title,40) }}</span>
  </div>

  <div class="row g-4">
    {{-- Left: Main content --}}
    <div class="col-lg-8">

      {{-- Image --}}
      @if($business->title_image)
      <img src="{{ url('images/property_title_img/'.$business->title_image) }}"
        style="width:100%;height:340px;object-fit:cover;border-radius:16px;margin-bottom:20px;"
        onerror="this.style.display='none'"/>
      @else
      <div style="width:100%;height:200px;background:linear-gradient(135deg,#F1F5F9,#E2E8F0);border-radius:16px;display:flex;align-items:center;justify-content:center;margin-bottom:20px;">
        <i class="fa-solid fa-store" style="font-size:60px;color:#CBD5E1;"></i>
      </div>
      @endif

      {{-- Title + Price + Ref --}}
      <div style="background:#fff;border:1px solid #E2E8F0;border-radius:16px;padding:24px;margin-bottom:16px;">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:12px;">
          <div>
            <span style="background:#E5343A;color:#fff;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;text-transform:uppercase;">
              {{ $business->business_type ?: 'Business For Sale' }}
            </span>
            <h1 style="font-size:clamp(20px,3vw,26px);font-weight:800;color:#0F172A;margin:10px 0 4px;">{{ $business->title }}</h1>
            <div style="font-size:14px;color:#64748B;">
              <i class="fa-solid fa-location-dot" style="color:#E5343A;margin-right:5px;"></i>
              {{ implode(', ', array_filter([$business->city, $business->state, $business->country])) }}
            </div>
          </div>
          <div style="text-align:right;">
            <div style="font-size:28px;font-weight:800;color:#E5343A;">{{ $priceF }}</div>
            @if($business->reference_no)
            <div style="display:flex;align-items:center;gap:6px;margin-top:6px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;padding:5px 10px;">
              <i class="fa-solid fa-hashtag" style="color:#E5343A;font-size:11px;"></i>
              <span style="font-family:monospace;font-size:12px;font-weight:700;color:#0F172A;">{{ $business->reference_no }}</span>
              <button onclick="navigator.clipboard.writeText('{{ $business->reference_no }}').then(()=>this.textContent='✓')"
                style="background:none;border:none;cursor:pointer;font-size:11px;color:#64748B;">Copy</button>
            </div>
            @endif
          </div>
        </div>
      </div>

      {{-- Business Key Stats --}}
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:16px;">
        @if(!empty($meta['turnover']))
        <div style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:12px;padding:14px;text-align:center;">
          <div style="font-size:10px;font-weight:700;color:#16A34A;text-transform:uppercase;margin-bottom:4px;">Monthly Turnover</div>
          <div style="font-size:16px;font-weight:800;color:#166534;">{{ $currency }}{{ $meta['turnover'] }}</div>
        </div>
        @endif
        @if(!empty($meta['profit_margin']))
        <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:12px;padding:14px;text-align:center;">
          <div style="font-size:10px;font-weight:700;color:#1D4ED8;text-transform:uppercase;margin-bottom:4px;">Net Profit Margin</div>
          <div style="font-size:16px;font-weight:800;color:#1D4ED8;">{{ $meta['profit_margin'] }}%</div>
        </div>
        @endif
        @if(!empty($meta['employees']))
        <div style="background:#FFF7ED;border:1px solid #FED7AA;border-radius:12px;padding:14px;text-align:center;">
          <div style="font-size:10px;font-weight:700;color:#C2410C;text-transform:uppercase;margin-bottom:4px;">Employees</div>
          <div style="font-size:16px;font-weight:800;color:#C2410C;">{{ $meta['employees'] }}</div>
        </div>
        @endif
        @if(!empty($meta['established_year']))
        <div style="background:#F5F3FF;border:1px solid #DDD6FE;border-radius:12px;padding:14px;text-align:center;">
          <div style="font-size:10px;font-weight:700;color:#7C3AED;text-transform:uppercase;margin-bottom:4px;">Established</div>
          <div style="font-size:16px;font-weight:800;color:#7C3AED;">{{ $meta['established_year'] }}</div>
        </div>
        @endif
      </div>

      {{-- Description --}}
      <div style="background:#fff;border:1px solid #E2E8F0;border-radius:16px;padding:24px;margin-bottom:16px;">
        <h3 style="font-size:16px;font-weight:700;margin:0 0 14px;">About This Business</h3>
        <p style="font-size:14px;color:#475569;line-height:1.8;margin:0;">{{ $business->description }}</p>
      </div>

      {{-- Business Details --}}
      @if(!empty($meta))
      <div style="background:#fff;border:1px solid #E2E8F0;border-radius:16px;padding:24px;margin-bottom:16px;">
        <h3 style="font-size:16px;font-weight:700;margin:0 0 16px;">Business Details</h3>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
          @foreach([
            'business_type'    => ['Type','fa-store'],
            'established_year' => ['Est. Year','fa-calendar'],
            'employees'        => ['Employees','fa-users'],
            'turnover'         => ['Monthly Turnover','fa-chart-line'],
            'profit_margin'    => ['Profit Margin (%)','fa-percent'],
            'reason_selling'   => ['Reason for Selling','fa-sign-out-alt'],
            'lease_type'       => ['Premises','fa-building'],
            'includes'         => ['Sale Includes','fa-box'],
          ] as $key => [$label,$icon])
          @php $val = $meta[$key] ?? ($business->$key ?? null); @endphp
          @if($val)
          <div style="display:flex;gap:10px;align-items:flex-start;">
            <div style="width:32px;height:32px;background:#FFF1F3;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
              <i class="fa-solid fa-{{ $icon }}" style="color:#E5343A;font-size:12px;"></i>
            </div>
            <div>
              <div style="font-size:11px;color:#94A3B8;font-weight:600;">{{ $label }}</div>
              <div style="font-size:13px;font-weight:600;color:#0F172A;">{{ $val }}</div>
            </div>
          </div>
          @endif
          @endforeach
        </div>
      </div>
      @endif

      {{-- Related --}}
      @if($related->isNotEmpty())
      <h3 style="font-size:16px;font-weight:700;margin:24px 0 12px;">Similar Businesses</h3>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;">
        @foreach($related as $r)
        <a href="/business/{{ $r->slug_id }}" style="text-decoration:none;background:#fff;border:1px solid #E2E8F0;border-radius:12px;overflow:hidden;display:block;">
          @if($r->title_image)
          <img src="{{ url('images/property_title_img/'.$r->title_image) }}" style="width:100%;height:120px;object-fit:cover;"/>
          @else
          <div style="width:100%;height:120px;background:#F1F5F9;display:flex;align-items:center;justify-content:center;"><i class="fa-solid fa-store" style="color:#CBD5E1;font-size:24px;"></i></div>
          @endif
          <div style="padding:12px;">
            <div style="font-size:13px;font-weight:700;color:#0F172A;margin-bottom:4px;">{{ Str::limit($r->title,40) }}</div>
            <div style="font-size:13px;font-weight:700;color:#E5343A;">{{ $r->price ? $currency.number_format($r->price) : 'Enquire' }}</div>
          </div>
        </a>
        @endforeach
      </div>
      @endif
    </div>

    {{-- Right: Enquiry Sidebar --}}
    <div class="col-lg-4">
      <div style="position:sticky;top:80px;">
        <div style="background:#fff;border:1px solid #E2E8F0;border-radius:16px;padding:24px;margin-bottom:16px;">
          <h4 style="font-size:16px;font-weight:700;margin:0 0 4px;">Interested in this business?</h4>
          <p style="font-size:13px;color:#64748B;margin:0 0 16px;">Send an enquiry and the owner will contact you.</p>
          <input id="eqName" type="text" placeholder="Your Name *" style="width:100%;border:1px solid #E2E8F0;border-radius:10px;padding:10px 14px;font-size:13px;outline:none;margin-bottom:10px;box-sizing:border-box;"/>
          <input id="eqMobile" type="tel" placeholder="Mobile Number *" style="width:100%;border:1px solid #E2E8F0;border-radius:10px;padding:10px 14px;font-size:13px;outline:none;margin-bottom:10px;box-sizing:border-box;"/>
          <input id="eqEmail" type="email" placeholder="Email (optional)" style="width:100%;border:1px solid #E2E8F0;border-radius:10px;padding:10px 14px;font-size:13px;outline:none;margin-bottom:10px;box-sizing:border-box;"/>
          <textarea id="eqMsg" rows="3" placeholder="Message (optional)" style="width:100%;border:1px solid #E2E8F0;border-radius:10px;padding:10px 14px;font-size:13px;outline:none;resize:none;margin-bottom:14px;box-sizing:border-box;"></textarea>
          <button onclick="submitEnquiry()" id="eqBtn"
            style="width:100%;background:#E5343A;color:#fff;border:none;border-radius:10px;padding:12px;font-size:14px;font-weight:700;cursor:pointer;">
            <i class="fa-regular fa-envelope me-2"></i> Send Enquiry
          </button>
        </div>

        {{-- Share --}}
        <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;padding:16px;">
          <div style="font-size:12px;font-weight:700;color:#64748B;margin-bottom:10px;">Share this listing</div>
          <div style="display:flex;gap:8px;">
            <a href="https://wa.me/?text={{ urlencode($business->title.' - '.$priceF.' '.url('/business/'.$business->slug_id)) }}" target="_blank"
              style="background:#25D366;color:#fff;border-radius:8px;padding:8px 14px;font-size:12px;font-weight:600;text-decoration:none;flex:1;text-align:center;">
              <i class="fa-brands fa-whatsapp me-1"></i> WhatsApp
            </a>
            <button onclick="navigator.clipboard.writeText(window.location.href).then(()=>this.textContent='Copied!')"
              style="background:#EFF6FF;color:#1D4ED8;border:1px solid #BFDBFE;border-radius:8px;padding:8px 14px;font-size:12px;font-weight:600;cursor:pointer;flex:1;">
              Copy Link
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

@endsection
@section('js')
<script>
async function submitEnquiry() {
  var name = document.getElementById('eqName').value.trim();
  var mob  = document.getElementById('eqMobile').value.trim();
  if (!name||!mob) { alert('Name and mobile are required.'); return; }
  var btn = document.getElementById('eqBtn');
  btn.textContent = 'Sending...'; btn.disabled = true;
  try {
    var res = await fetch('/business/enquiry',{
      method:'POST',
      headers:{'Content-Type':'application/json','X-CSRF-TOKEN':'{{ csrf_token() }}','Accept':'application/json'},
      body: JSON.stringify({
        property_id: {{ $business->id }},
        name: name, mobile: mob,
        email: document.getElementById('eqEmail').value,
        message: document.getElementById('eqMsg').value
      })
    });
    var d = await res.json();
    if(d.success) alert('Enquiry sent! The owner will contact you shortly.');
  } catch(e) {}
  btn.innerHTML = '<i class="fa-regular fa-envelope me-2"></i> Send Enquiry';
  btn.disabled = false;
}
</script>
@endsection
