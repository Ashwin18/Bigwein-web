@extends('frontend.layouts.app')
@section('title', ($project->translated_title ?? $project->title).' — BigWein Projects')
@section('content')
@php
  $title    = $project->translated_title ?? $project->title ?? 'Project';
  $location = implode(', ', array_filter([$project->location, $project->city, $project->state]));
  $currency = $s['currency_symbol'] ?? '₹';
  $gallery  = $project->gallary_images ?? collect();
  $plans    = $project->plans ?? collect();
  $docs     = $project->project_documetns ?? collect();
  $statusColor = match($project->type ?? '') {
    'Ready to Move'      => ['bg'=>'#F0FDF4','color'=>'#166534','border'=>'#16A34A'],
    'Under Construction' => ['bg'=>'#FFFBEB','color'=>'#92400E','border'=>'#D97706'],
    'New Launch'         => ['bg'=>'#FFF1F3','color'=>'#9F1239','border'=>'#E5343A'],
    default              => ['bg'=>'#F3F4F6','color'=>'#374151','border'=>'#64748B'],
  };
@endphp

<style>
.pjd-hero{background:#0F172A;padding:12px 0;border-bottom:1px solid #1E293B;}
.pjd-layout{display:grid;grid-template-columns:1fr 340px;gap:28px;padding:28px 0 60px;align-items:start;}
.pjd-gallery{border-radius:16px;overflow:hidden;background:#F1F5F9;margin-bottom:20px;}
.pjd-main-img{width:100%;height:420px;object-fit:cover;display:block;}
.pjd-main-placeholder{width:100%;height:420px;display:flex;align-items:center;justify-content:center;background:#E2E8F0;}
.pjd-thumbs{display:flex;gap:8px;padding:10px;overflow-x:auto;}
.pjd-thumb{width:80px;height:60px;object-fit:cover;border-radius:8px;cursor:pointer;opacity:.65;transition:opacity .2s;flex-shrink:0;border:2px solid transparent;}
.pjd-thumb.active,.pjd-thumb:hover{opacity:1;border-color:var(--red);}
.pjd-section{margin-bottom:28px;}
.pjd-section-title{font-size:17px;font-weight:700;color:#0F172A;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px;}
.pjd-section-title i{color:var(--red);}
.pjd-highlights{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.pjd-hl-item{background:#F8FAFC;border:1px solid var(--border);border-radius:10px;padding:12px 14px;display:flex;align-items:center;gap:10px;}
.pjd-hl-icon{width:36px;height:36px;background:#FFF1F3;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:16px;color:var(--red);}
.pjd-hl-label{font-size:11px;color:#64748B;}
.pjd-hl-value{font-size:13px;font-weight:700;color:#0F172A;}
.pjd-plan-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;}
.pjd-plan-item{border:1px solid var(--border);border-radius:10px;overflow:hidden;cursor:pointer;}
.pjd-plan-img{width:100%;height:100px;object-fit:cover;}
.pjd-plan-label{padding:6px 10px;font-size:11px;font-weight:600;color:#374151;}
.pjd-doc-list{display:flex;flex-direction:column;gap:8px;}
.pjd-doc-item{display:flex;align-items:center;gap:10px;padding:10px 14px;border:1px solid var(--border);border-radius:10px;text-decoration:none;color:#374151;transition:border-color .15s;}
.pjd-doc-item:hover{border-color:var(--red);color:var(--red);}
.pjd-sidebar{position:sticky;top:86px;}
.pjd-enquiry-card{background:#fff;border:1px solid var(--border);border-radius:16px;overflow:hidden;margin-bottom:16px;}
.pjd-eq-header{background:var(--red);padding:16px 20px;color:#fff;}
.pjd-eq-body{padding:18px 20px;}
.pjd-action-btn{width:100%;padding:11px;border:none;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;text-decoration:none;margin-bottom:8px;transition:opacity .15s;}
.pjd-action-btn:hover{opacity:.9;}
.pjd-info-card{background:#fff;border:1px solid var(--border);border-radius:14px;padding:16px 20px;margin-bottom:16px;}
.pjd-info-row{display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border);font-size:13px;}
.pjd-info-row:last-child{border-bottom:none;}
.pjd-info-lbl{color:#64748B;display:flex;align-items:center;gap:6px;}
.pjd-info-val{font-weight:600;color:#0F172A;}
.similar-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:20px;}
.pjd-lightbox{display:none;position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:9999;align-items:center;justify-content:center;}
.pjd-lightbox.open{display:flex;}
.pjd-lb-img{max-width:90vw;max-height:88vh;border-radius:8px;object-fit:contain;}
.pjd-lb-close{position:absolute;top:20px;right:24px;font-size:32px;color:#fff;cursor:pointer;line-height:1;}
.pjd-lb-nav{position:absolute;top:50%;transform:translateY(-50%);font-size:24px;color:#fff;background:rgba(255,255,255,.15);border:none;border-radius:50%;width:44px;height:44px;cursor:pointer;display:flex;align-items:center;justify-content:center;}
.pjd-lb-prev{left:16px;} .pjd-lb-next{right:16px;}
@media(max-width:900px){.pjd-layout{grid-template-columns:1fr;}.pjd-sidebar{position:static;}.similar-grid{grid-template-columns:1fr 1fr;}}
@media(max-width:600px){.pjd-main-img{height:240px;}.pjd-highlights{grid-template-columns:1fr;}.similar-grid{grid-template-columns:1fr;}.pjd-thumbs{gap:6px;}.pjd-thumb{width:64px;height:48px;}}
</style>

{{-- Breadcrumb hero --}}
<div class="pjd-hero">
  <div class="container">
    <div style="display:flex;align-items:center;gap:8px;font-size:12px;color:rgba(255,255,255,.55);">
      <a href="/" style="color:rgba(255,255,255,.55);text-decoration:none;">Home</a>
      <i class="fa-solid fa-chevron-right fa-xs"></i>
      <a href="/projects" style="color:rgba(255,255,255,.55);text-decoration:none;">Projects</a>
      <i class="fa-solid fa-chevron-right fa-xs"></i>
      <span style="color:#fff;">{{ Str::limit($title,40) }}</span>
    </div>
  </div>
</div>

<div class="container">
  <div class="pjd-layout">

    {{-- ── LEFT: MAIN CONTENT ── --}}
    <div>

      {{-- Gallery --}}
      <div class="pjd-gallery">
        @if($project->image)
          <img src="{{ $project->image }}" alt="{{ $title }}" class="pjd-main-img" id="pjdMainImg"
            onclick="openLightbox(0)" style="cursor:zoom-in;"
            onerror="this.style.display='none';document.getElementById('pjdPlaceholder').style.display='flex'"/>
          <div id="pjdPlaceholder" class="pjd-main-placeholder" style="display:none;">
            <i class="fa-solid fa-city" style="font-size:56px;color:#CBD5E1;"></i>
          </div>
        @else
          <div class="pjd-main-placeholder">
            <i class="fa-solid fa-city" style="font-size:56px;color:#CBD5E1;"></i>
          </div>
        @endif
        @if($gallery->isNotEmpty())
        <div class="pjd-thumbs">
          @if($project->image)
          <img src="{{ $project->image }}" alt="Main" class="pjd-thumb active" id="pjdThumb0"
            onclick="switchImg('{{ $project->image }}', 0)"/>
          @endif
          @foreach($gallery as $gi => $img)
          @php $thumbSrc = $img->image_url ?? url('storage/'.$img->image_path); $thumbIdx = $gi+1; @endphp
          <img src="{{ $thumbSrc }}" alt="Image {{ $thumbIdx }}" class="pjd-thumb" id="pjdThumb{{ $thumbIdx }}"
            onclick="switchImg('{{ $thumbSrc }}', {{ $thumbIdx }})"/>
          @endforeach
        </div>
        @endif
      </div>

      {{-- Title and badges --}}
      <div class="pjd-section">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:12px;">
          <div>
            <h1 style="font-size:clamp(20px,2.5vw,28px);font-weight:800;color:#0F172A;line-height:1.2;margin-bottom:8px;">{{ $title }}</h1>

    {{-- Reference Number --}}
    @if(!empty($project->reference_no))
    <div style="display:inline-flex;align-items:center;gap:8px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;padding:8px 14px;margin-bottom:16px;">
      <i class="fa-solid fa-hashtag" style="color:#E5343A;font-size:13px;"></i>
      <div>
        <div style="font-size:10px;color:#94A3B8;font-weight:600;text-transform:uppercase;letter-spacing:.5px;">Reference No.</div>
        <div style="font-size:14px;font-weight:800;color:#0F172A;font-family:monospace;letter-spacing:1px;">{{ $project->reference_no }}</div>
      </div>
      <button onclick="navigator.clipboard.writeText('{{ $project->reference_no }}').then(()=>this.innerHTML='<i class=\'fa-solid fa-check\'></i> Copied!')"
        style="background:#E5343A;color:#fff;border:none;border-radius:7px;padding:4px 10px;font-size:11px;font-weight:600;cursor:pointer;white-space:nowrap;">
        <i class="fa-regular fa-copy"></i> Copy
      </button>
    </div>
    @endif

            <p style="font-size:14px;color:#64748B;margin-bottom:10px;display:flex;align-items:center;gap:6px;">
              <i class="fa-solid fa-location-dot" style="color:var(--red);"></i> {{ $location ?: 'India' }}
            </p>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              @if($project->type)
              <span style="padding:5px 14px;border-radius:20px;font-size:12px;font-weight:700;background:{{ $statusColor['bg'] }};color:{{ $statusColor['color'] }};border:1px solid {{ $statusColor['border'] }};">
                {{ $project->type }}
              </span>
              @endif
              @if($project->category)
              <span style="padding:5px 14px;border-radius:20px;font-size:12px;font-weight:700;background:#EFF6FF;color:#1D4ED8;">
                {{ $project->category->category ?? '' }}
              </span>
              @endif
              <span style="padding:5px 14px;border-radius:20px;font-size:12px;font-weight:700;background:#F1F5F9;color:#374151;">
                <i class="fa-solid fa-eye fa-xs"></i> {{ number_format($project->total_click) }} views
              </span>
            </div>
          </div>
          <div style="text-align:right;flex-shrink:0;">
            <div style="font-size:11px;color:#64748B;">Price</div>
            <div style="font-size:22px;font-weight:800;color:var(--red);">Price on Request</div>
          </div>
        </div>
      </div>

      {{-- Overview / Description --}}
      @if($project->description)
      <div class="pjd-section">
        <h2 class="pjd-section-title"><i class="fa-solid fa-align-left"></i> About This Project</h2>
        <div style="font-size:14px;color:#374151;line-height:1.8;">{{ $project->description }}</div>
      </div>
      @endif

      {{-- Highlights --}}
      <div class="pjd-section">
        <h2 class="pjd-section-title"><i class="fa-solid fa-list-check"></i> Project Highlights</h2>
        <div class="pjd-highlights">
          @if($project->city)
          <div class="pjd-hl-item">
            <div class="pjd-hl-icon"><i class="fa-solid fa-city"></i></div>
            <div><div class="pjd-hl-label">City</div><div class="pjd-hl-value">{{ $project->city }}</div></div>
          </div>
          @endif
          @if($project->state)
          <div class="pjd-hl-item">
            <div class="pjd-hl-icon"><i class="fa-solid fa-map-location-dot"></i></div>
            <div><div class="pjd-hl-label">State</div><div class="pjd-hl-value">{{ $project->state }}</div></div>
          </div>
          @endif
          @if($project->type)
          <div class="pjd-hl-item">
            <div class="pjd-hl-icon"><i class="fa-solid fa-clock-rotate-left"></i></div>
            <div><div class="pjd-hl-label">Status</div><div class="pjd-hl-value">{{ $project->type }}</div></div>
          </div>
          @endif
          @if($project->category)
          <div class="pjd-hl-item">
            <div class="pjd-hl-icon"><i class="fa-solid fa-tag"></i></div>
            <div><div class="pjd-hl-label">Category</div><div class="pjd-hl-value">{{ $project->category->category ?? '—' }}</div></div>
          </div>
          @endif
          @if($project->location)
          <div class="pjd-hl-item" style="grid-column:1/-1;">
            <div class="pjd-hl-icon"><i class="fa-solid fa-location-dot"></i></div>
            <div><div class="pjd-hl-label">Address</div><div class="pjd-hl-value">{{ $project->location }}</div></div>
          </div>
          @endif
        </div>
      </div>

      {{-- Floor Plans --}}
      @if($plans->isNotEmpty())
      <div class="pjd-section">
        <h2 class="pjd-section-title"><i class="fa-solid fa-floor-plan"></i> Floor Plans</h2>
        <div class="pjd-plan-grid">
          @foreach($plans as $plan)
          @php $planImg = $plan->image ?? url('storage/'.($plan->image_path??'')); @endphp
          <div class="pjd-plan-item" onclick="openPlanLightbox('{{ $planImg }}')">
            <img src="{{ $planImg }}" alt="Floor Plan" class="pjd-plan-img" onerror="this.src=''"/>
            <div class="pjd-plan-label">{{ $plan->title ?? 'Floor Plan' }}</div>
          </div>
          @endforeach
        </div>
      </div>
      @endif

      {{-- Documents --}}
      @if($docs->where('type','doc')->isNotEmpty())
      <div class="pjd-section">
        <h2 class="pjd-section-title"><i class="fa-solid fa-file-contract"></i> Documents</h2>
        <div class="pjd-doc-list">
          @foreach($docs->where('type','doc') as $doc)
          <a href="{{ $doc->file_url ?? '#' }}" target="_blank" class="pjd-doc-item">
            <i class="fa-solid fa-file-pdf" style="color:var(--red);font-size:20px;"></i>
            <span style="font-size:13px;font-weight:600;">{{ $doc->title ?? 'Project Document' }}</span>
            <i class="fa-solid fa-download" style="margin-left:auto;color:#94A3B8;"></i>
          </a>
          @endforeach
        </div>
      </div>
      @endif

      {{-- Location Map --}}
      @if($project->latitude && $project->longitude)
      <div class="pjd-section">
        <h2 class="pjd-section-title"><i class="fa-solid fa-map"></i> Location</h2>
        <div style="border-radius:12px;overflow:hidden;border:1px solid var(--border);">
          <iframe
            src="https://maps.google.com/maps?q={{ $project->latitude }},{{ $project->longitude }}&z=15&output=embed"
            width="100%" height="280" style="border:0;display:block;" loading="lazy"></iframe>
        </div>
      </div>
      @endif

    </div>

    {{-- ── RIGHT: SIDEBAR ── --}}
    <div class="pjd-sidebar">

      {{-- Enquiry card --}}
      <div class="pjd-enquiry-card">
        <div class="pjd-eq-header">
          <div style="font-size:15px;font-weight:700;margin-bottom:2px;">Interested in this Project?</div>
          <div style="font-size:12px;opacity:.8;">Get details, pricing & site visit</div>
        </div>
        <div class="pjd-eq-body">
          <a href="tel:{{ $s['company_tel1'] ?? '' }}" class="pjd-action-btn" style="background:var(--red);color:#fff;">
            <i class="fa-solid fa-phone"></i> Call Now
          </a>
          <a href="https://wa.me/91{{ preg_replace('/\D/','',$s['company_tel1']??'') }}?text={{ urlencode('Hi, I am interested in '.$title.' project. Please share details.') }}"
            target="_blank" class="pjd-action-btn" style="background:#25D366;color:#fff;">
            <i class="fa-brands fa-whatsapp"></i> WhatsApp
          </a>
          <button onclick="document.getElementById('pjdEnquiryForm').style.display='block';this.style.display='none'"
            class="pjd-action-btn" style="background:#F1F5F9;color:#0F172A;margin-bottom:0;">
            <i class="fa-solid fa-envelope"></i> Send Enquiry
          </button>
          <div id="pjdEnquiryForm" style="display:none;margin-top:12px;border-top:1px solid var(--border);padding-top:14px;">
            <input type="text" id="pjdName" placeholder="Your Name *" style="width:100%;padding:9px 12px;border:1px solid var(--border);border-radius:8px;font-size:13px;margin-bottom:8px;outline:none;font-family:inherit;"/>
            <input type="tel" id="pjdPhone" placeholder="Mobile Number *" style="width:100%;padding:9px 12px;border:1px solid var(--border);border-radius:8px;font-size:13px;margin-bottom:8px;outline:none;font-family:inherit;"/>
            <textarea id="pjdMsg" placeholder="Message (optional)" rows="2" style="width:100%;padding:9px 12px;border:1px solid var(--border);border-radius:8px;font-size:13px;margin-bottom:10px;outline:none;resize:none;font-family:inherit;"></textarea>
            <button onclick="submitProjectEnquiry()" class="pjd-action-btn" style="background:var(--red);color:#fff;margin-bottom:0;">
              <i class="fa-solid fa-paper-plane"></i> Submit Enquiry
            </button>
          </div>
        </div>
      </div>

      {{-- Project info card --}}
      <div class="pjd-info-card">
        <div style="font-size:14px;font-weight:700;color:#0F172A;margin-bottom:12px;display:flex;align-items:center;gap:7px;">
          <i class="fa-solid fa-circle-info" style="color:var(--red);"></i> Project Info
        </div>
        <div class="pjd-info-row">
          <span class="pjd-info-lbl"><i class="fa-solid fa-tag"></i> Category</span>
          <span class="pjd-info-val">{{ $project->category->category ?? 'Property' }}</span>
        </div>
        <div class="pjd-info-row">
          <span class="pjd-info-lbl"><i class="fa-solid fa-clock-rotate-left"></i> Status</span>
          <span class="pjd-info-val" style="color:{{ $statusColor['color'] }};">{{ $project->type ?? 'N/A' }}</span>
        </div>
        <div class="pjd-info-row">
          <span class="pjd-info-lbl"><i class="fa-solid fa-location-dot"></i> City</span>
          <span class="pjd-info-val">{{ $project->city ?? 'N/A' }}</span>
        </div>
        <div class="pjd-info-row">
          <span class="pjd-info-lbl"><i class="fa-solid fa-map"></i> State</span>
          <span class="pjd-info-val">{{ $project->state ?? 'N/A' }}</span>
        </div>
        <div class="pjd-info-row">
          <span class="pjd-info-lbl"><i class="fa-solid fa-eye"></i> Views</span>
          <span class="pjd-info-val">{{ number_format($project->total_click) }}</span>
        </div>
        <div class="pjd-info-row">
          <span class="pjd-info-lbl"><i class="fa-solid fa-building"></i> Builder</span>
          <span class="pjd-info-val">{{ $project->customer->name ?? 'BigWein' }}</span>
        </div>
      </div>

      {{-- Share --}}
      <div class="pjd-info-card">
        <div style="font-size:13px;font-weight:700;color:#0F172A;margin-bottom:10px;">Share this project</div>
        <div style="display:flex;gap:8px;">
          <a href="https://wa.me/?text={{ urlencode($title.' — '.url()->current()) }}" target="_blank"
            style="flex:1;padding:8px;background:#25D366;color:#fff;border-radius:8px;text-decoration:none;text-align:center;font-size:13px;">
            <i class="fa-brands fa-whatsapp"></i>
          </a>
          <a href="https://www.facebook.com/sharer/sharer.php?u={{ urlencode(url()->current()) }}" target="_blank"
            style="flex:1;padding:8px;background:#1877F2;color:#fff;border-radius:8px;text-decoration:none;text-align:center;font-size:13px;">
            <i class="fa-brands fa-facebook-f"></i>
          </a>
          <button onclick="copyProjectLink()" id="pjdCopyBtn"
            style="flex:1;padding:8px;background:#F1F5F9;color:#374151;border:none;border-radius:8px;cursor:pointer;font-size:13px;">
            <i class="fa-solid fa-link"></i>
          </button>
        </div>
      </div>

    </div>
  </div>

  {{-- Similar Projects --}}
  @if($similar->isNotEmpty())
  <div style="padding-bottom:48px;">
    <h2 style="font-size:22px;font-weight:800;color:#0F172A;margin-bottom:4px;">Similar Projects</h2>
    <p style="color:#64748B;font-size:14px;margin-bottom:20px;">You might also be interested in these</p>
    <div class="similar-grid">
      @foreach($similar as $sp)
      @php $spTitle = $sp->translated_title ?? $sp->title ?? 'Project'; @endphp
      <a href="/project/{{ $sp->slug_id }}" style="text-decoration:none;">
        <div style="background:#fff;border:1px solid var(--border);border-radius:14px;overflow:hidden;transition:all .2s;" onmouseover="this.style.borderColor='var(--red)';this.style.transform='translateY(-3px)'" onmouseout="this.style.borderColor='var(--border)';this.style.transform='translateY(0)'">
          <div style="height:140px;overflow:hidden;position:relative;background:#F1F5F9;">
            @if($sp->image)
              <img src="{{ $sp->image }}" alt="{{ $spTitle }}" style="width:100%;height:100%;object-fit:cover;"/>
            @else
              <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;"><i class="fa-solid fa-city" style="font-size:36px;color:#CBD5E1;"></i></div>
            @endif
            @if($sp->type)<span style="position:absolute;top:8px;left:8px;background:rgba(0,0,0,.65);color:#fff;font-size:10px;font-weight:600;padding:3px 9px;border-radius:12px;">{{ $sp->type }}</span>@endif
          </div>
          <div style="padding:14px;">
            <h3 style="font-size:14px;font-weight:700;color:#0F172A;margin-bottom:6px;line-height:1.3;">{{ Str::limit($spTitle,40) }}</h3>
            <p style="font-size:12px;color:#64748B;margin-bottom:8px;display:flex;align-items:center;gap:4px;"><i class="fa-solid fa-location-dot" style="color:var(--red);"></i> {{ $sp->city ?: 'India' }}</p>
            <span style="font-size:11px;font-weight:700;color:var(--red);">Price on Request →</span>
          </div>
        </div>
      </a>
      @endforeach
    </div>
  </div>
  @endif
</div>

{{-- Lightbox --}}
<div class="pjd-lightbox" id="pjdLightbox" onclick="closeLightbox(event)">
  <button class="pjd-lb-close" onclick="closeLightboxDirect()">&times;</button>
  <button class="pjd-lb-nav pjd-lb-prev" onclick="lbNav(-1)"><i class="fa-solid fa-chevron-left"></i></button>
  <img src="" alt="" class="pjd-lb-img" id="pjdLbImg"/>
  <button class="pjd-lb-nav pjd-lb-next" onclick="lbNav(1)"><i class="fa-solid fa-chevron-right"></i></button>
</div>

@endsection
@section('script')
<script>
const pjdAllImgs = [
  @if($project->image)'{{ $project->image }}',@endif
  @foreach($gallery as $img)'{{ $img->image_url ?? url("storage/".($img->image_path??"")) }}',@endforeach
];
let pjdLbIdx = 0;

function switchImg(src, idx) {
  document.getElementById('pjdMainImg') && (document.getElementById('pjdMainImg').src = src);
  document.querySelectorAll('.pjd-thumb').forEach((t,i) => t.classList.toggle('active', i===idx));
}

function openLightbox(idx) {
  pjdLbIdx = idx;
  document.getElementById('pjdLbImg').src = pjdAllImgs[idx] || '';
  document.getElementById('pjdLightbox').classList.add('open');
}
function openPlanLightbox(src) {
  document.getElementById('pjdLbImg').src = src;
  document.getElementById('pjdLightbox').classList.add('open');
}
function closeLightbox(e) { if(e.target===document.getElementById('pjdLightbox')) closeLightboxDirect(); }
function closeLightboxDirect() { document.getElementById('pjdLightbox').classList.remove('open'); }
function lbNav(dir) {
  pjdLbIdx = ((pjdLbIdx + dir) + pjdAllImgs.length) % pjdAllImgs.length;
  document.getElementById('pjdLbImg').src = pjdAllImgs[pjdLbIdx];
  event.stopPropagation();
}
document.addEventListener('keydown', e => {
  if (document.getElementById('pjdLightbox').classList.contains('open')) {
    if (e.key==='Escape') closeLightboxDirect();
    if (e.key==='ArrowLeft') lbNav(-1);
    if (e.key==='ArrowRight') lbNav(1);
  }
});

function copyProjectLink() {
  navigator.clipboard.writeText(window.location.href);
  const btn = document.getElementById('pjdCopyBtn');
  btn.innerHTML = '<i class="fa-solid fa-check"></i>';
  btn.style.background = '#F0FDF4'; btn.style.color = '#16A34A';
  setTimeout(() => { btn.innerHTML='<i class="fa-solid fa-link"></i>'; btn.style.background='#F1F5F9'; btn.style.color='#374151'; }, 2000);
}

async function submitProjectEnquiry() {
  const name  = document.getElementById('pjdName').value.trim();
  const phone = document.getElementById('pjdPhone').value.trim();
  const msg   = document.getElementById('pjdMsg').value.trim();
  if (!name || !phone) { alert('Please enter your name and phone number.'); return; }
  try {
    const res = await fetch('{{ url("bw-api/inquire") }}', {
      method:'POST',
      headers:{'Content-Type':'application/json','X-CSRF-TOKEN':'{{ csrf_token() }}','Accept':'application/json'},
      body: JSON.stringify({ property_id: null, project_id: {{ $project->id }}, name, mobile: phone, message: msg || 'Interested in '+{{ json_encode($title) }}, type:'Message' })
    });
    const data = await res.json();
    alert(data.message || 'Enquiry sent! We will contact you shortly.');
    document.getElementById('pjdEnquiryForm').style.display='none';
  } catch(e) { alert('Enquiry sent! We will contact you shortly.'); }
}
</script>
@endsection
