@extends('layouts.main')
@section('title') Review Property @endsection
@section('page-title')
<div class="page-title">
  <div class="row">
    <div class="col-12 col-md-6 order-md-1 order-last">
      <h4><i class="bi bi-clipboard-check-fill me-2" style="color:#e30620;"></i>Review Property</h4>
      <nav aria-label="breadcrumb"><ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ url('home') }}">Home</a></li>
        <li class="breadcrumb-item"><a href="{{ url('property-approval') }}">Property Approval</a></li>
        <li class="breadcrumb-item active">Review</li>
      </ol></nav>
    </div>
    <div class="col-12 col-md-6 order-md-2 order-first d-flex justify-content-md-end align-items-center gap-2 mt-2 mt-md-0">
      @if($prop->request_status === 'pending')
      <button class="btn btn-success" onclick="approveProperty({{ $prop->id }})" style="border-radius:10px;font-weight:700;">
        <i class="bi bi-check-circle-fill me-1"></i> Approve & Publish
      </button>
      <button class="btn btn-danger" onclick="openRejectModal({{ $prop->id }},'{{ addslashes($prop->title) }}')" style="border-radius:10px;font-weight:700;">
        <i class="bi bi-x-circle-fill me-1"></i> Reject
      </button>
      @else
      <span class="badge bg-{{ $prop->request_status==='approved'?'success':'danger' }}" style="font-size:14px;padding:10px 18px;border-radius:10px;">
        {{ ucfirst($prop->request_status) }}
      </span>
      @endif
    </div>
  </div>
</div>
@endsection

@section('content')
<section class="section">
<div class="row">

  {{-- LEFT: Property Details --}}
  <div class="col-xl-8 mb-4">

    {{-- Images --}}
    <div class="card border-0 mb-4" style="border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.07);">
      <div class="card-body p-3">
        @if($prop->title_image)
        <img src="{{ url('images/'.config('global.PROPERTY_TITLE_IMG_PATH','property_title_img/').$prop->title_image) }}"
          style="width:100%;height:320px;object-fit:cover;border-radius:12px;" alt="Main Image"/>
        @else
        <div style="width:100%;height:200px;background:#EEF2FF;border-radius:12px;display:flex;align-items:center;justify-content:center;">
          <i class="bi bi-building" style="font-size:64px;color:#818CF8;"></i>
        </div>
        @endif
        @if($gallery->count())
        <div class="d-flex gap-2 mt-2 overflow-auto">
          @foreach($gallery as $img)
          <img src="{{ url('images/'.config('global.PROPERTY_GALLERY_IMG_PATH','property_gallery_img/').'/'.$prop->id.'/'.$img->image) }}"
            style="width:100px;height:70px;object-fit:cover;border-radius:8px;flex-shrink:0;" alt="Gallery"/>
          @endforeach
        </div>
        @endif
      </div>
    </div>

    {{-- Basic Info --}}
    <div class="card border-0 mb-4" style="border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.07);">
      <div class="card-header bg-white" style="border-radius:16px 16px 0 0;"><h6 class="mb-0" style="font-weight:700;"><i class="bi bi-info-circle-fill me-2" style="color:#e30620;"></i>Property Information</h6></div>
      <div class="card-body">
        <h4 style="font-weight:800;color:#111;margin-bottom:6px;">{{ $prop->title }}</h4>
        <div class="d-flex align-items-center gap-3 mb-3 flex-wrap">
          <span style="background:#EFF6FF;color:#2563EB;padding:4px 12px;border-radius:8px;font-size:12px;font-weight:700;">{{ $prop->category_name }}</span>
          <span style="background:{{ $prop->propery_type==0?'#E0F2FE':'#FFFBEB' }};color:{{ $prop->propery_type==0?'#0369A1':'#D97706' }};padding:4px 12px;border-radius:8px;font-size:12px;font-weight:700;">
            {{ $prop->propery_type == 0 ? 'For Sale' : 'For Rent' }}
          </span>
          <span style="color:#6B7280;font-size:13px;"><i class="bi bi-geo-alt-fill me-1" style="color:#e30620;"></i>{{ $prop->city }}{{ $prop->state?', '.$prop->state:'' }}{{ $prop->pincode?' - '.$prop->pincode:'' }}</span>
        </div>
        <div style="font-size:28px;font-weight:900;color:#e30620;margin-bottom:16px;">
          ₹{{ number_format($prop->price) }}
          @if($prop->price_negotiable)<small style="font-size:14px;font-weight:500;color:#6B7280;"> (Negotiable)</small>@endif
        </div>

        <div class="row g-3 mb-3">
          @foreach([
            ['Total Area', $prop->total_area ? number_format($prop->total_area).' sqft' : '—','rulers'],
            ['Carpet Area', $prop->carpet_area ? number_format($prop->carpet_area).' sqft' : '—','square'],
            ['Floor', $prop->floor_number ? $prop->floor_number.'/'.$prop->total_floors : '—','layers'],
            ['Facing', $prop->facing ?? '—','compass'],
            ['Furnishing', $prop->furnishing ?? '—','couch'],
            ['Age', $prop->age_of_building ?? '—','clock'],
            ['Water Supply', $prop->water_supply ?? '—','droplet'],
            ['Status', $prop->prop_status ?? '—','circle-check'],
          ] as $info)
          <div class="col-xl-3 col-6">
            <div style="background:#F9FAFB;border-radius:10px;padding:12px;">
              <div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;color:#9CA3AF;margin-bottom:3px;"><i class="bi bi-{{ $info[2] }} me-1"></i>{{ $info[0] }}</div>
              <div style="font-size:14px;font-weight:700;color:#111;">{{ $info[1] }}</div>
            </div>
          </div>
          @endforeach
        </div>

        @if($prop->description)
        <div>
          <div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;color:#9CA3AF;margin-bottom:8px;">Description</div>
          <p style="font-size:14px;color:#374151;line-height:1.7;">{{ $prop->description }}</p>
        </div>
        @endif
      </div>
    </div>

    {{-- Parameters --}}
    @if($parameters->count())
    <div class="card border-0 mb-4" style="border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.07);">
      <div class="card-header bg-white" style="border-radius:16px 16px 0 0;"><h6 class="mb-0" style="font-weight:700;"><i class="bi bi-list-check me-2" style="color:#e30620;"></i>Amenities & Features</h6></div>
      <div class="card-body">
        <div class="row g-2">
          @foreach($parameters as $param)
          <div class="col-md-3 col-6">
            <div style="background:#F9FAFB;border-radius:10px;padding:12px;text-align:center;">
              <div style="font-size:20px;font-weight:800;color:#111;">{{ $param->value }}</div>
              <div style="font-size:11px;color:#9CA3AF;margin-top:2px;">{{ $param->name }}</div>
            </div>
          </div>
          @endforeach
        </div>
      </div>
    </div>
    @endif

    {{-- Nearby Facilities --}}
    @if($facilities->count())
    <div class="card border-0" style="border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.07);">
      <div class="card-header bg-white" style="border-radius:16px 16px 0 0;"><h6 class="mb-0" style="font-weight:700;"><i class="bi bi-geo-fill me-2" style="color:#e30620;"></i>Nearby Facilities</h6></div>
      <div class="card-body">
        <div class="row g-2">
          @foreach($facilities as $fac)
          <div class="col-md-4 col-6">
            <div style="background:#F9FAFB;border-radius:10px;padding:10px 12px;display:flex;align-items:center;gap:8px;">
              <i class="bi bi-geo-alt-fill" style="color:#e30620;font-size:16px;flex-shrink:0;"></i>
              <div>
                <div style="font-size:12px;font-weight:700;color:#111;">{{ $fac->name }}</div>
                <div style="font-size:11px;color:#9CA3AF;">{{ $fac->distance }} km away</div>
              </div>
            </div>
          </div>
          @endforeach
        </div>
      </div>
    </div>
    @endif
  </div>

  {{-- RIGHT: Owner + Action Panel --}}
  <div class="col-xl-4">

    {{-- Quick Action Card --}}
    @if($prop->request_status === 'pending')
    <div class="card border-0 mb-4" style="border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.07);border:2px solid #FEF9C3!important;">
      <div class="card-body p-4 text-center">
        <i class="bi bi-hourglass-split" style="font-size:40px;color:#D97706;display:block;margin-bottom:12px;"></i>
        <h5 style="font-weight:800;color:#111;margin-bottom:6px;">Awaiting Review</h5>
        <p style="font-size:13px;color:#6B7280;margin-bottom:20px;">This property was submitted by an owner and needs your review before going live.</p>
        <button class="btn btn-success w-100 mb-2" onclick="approveProperty({{ $prop->id }})" style="border-radius:10px;font-weight:700;padding:12px;">
          <i class="bi bi-check-circle-fill me-1"></i> Approve & Publish
        </button>
        <button class="btn btn-outline-danger w-100" onclick="openRejectModal({{ $prop->id }},'{{ addslashes($prop->title) }}')" style="border-radius:10px;font-weight:700;padding:12px;">
          <i class="bi bi-x-circle-fill me-1"></i> Reject Property
        </button>
      </div>
    </div>
    @endif

    {{-- Owner Card --}}
    <div class="card border-0 mb-4" style="border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.07);">
      <div class="card-header bg-white" style="border-radius:16px 16px 0 0;"><h6 class="mb-0" style="font-weight:700;"><i class="bi bi-person-badge-fill me-2" style="color:#e30620;"></i>Listed By</h6></div>
      <div class="card-body">
        <div class="d-flex align-items-center gap-3 mb-3">
          <div style="width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,#e30620,#FF6B6B);display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:800;color:#fff;flex-shrink:0;">
            {{ strtoupper(substr($prop->owner_name,0,1)) }}
          </div>
          <div>
            <div style="font-weight:700;font-size:14px;">{{ $prop->owner_name }}</div>
            <div style="font-size:11px;color:#9CA3AF;">{{ $prop->owner_type === 'builder' ? 'Builder / Developer' : 'Seller / Owner' }}</div>
          </div>
        </div>
        @foreach([['envelope',$prop->owner_email],['telephone',$prop->owner_mobile],['building',$prop->company_name]] as $info)
        @if($info[1])
        <div class="d-flex align-items-center gap-2 mb-2">
          <i class="bi bi-{{ $info[0] }}" style="color:#e30620;font-size:13px;width:16px;flex-shrink:0;"></i>
          <span style="font-size:13px;font-weight:500;">{{ $info[1] }}</span>
        </div>
        @endif
        @endforeach
        <div class="mt-3">
          <a href="{{ url('owner-management/'.($prop->added_by ?? '')) }}" class="btn btn-sm btn-outline-secondary w-100" style="border-radius:8px;font-size:12px;">
            <i class="bi bi-person-fill me-1"></i> View Owner Profile
          </a>
        </div>
      </div>
    </div>

    {{-- Submission Info --}}
    <div class="card border-0" style="border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.07);">
      <div class="card-header bg-white" style="border-radius:16px 16px 0 0;"><h6 class="mb-0" style="font-weight:700;"><i class="bi bi-clock-fill me-2" style="color:#e30620;"></i>Submission Info</h6></div>
      <div class="card-body">
        @foreach([
          ['Submitted On', \Carbon\Carbon::parse($prop->created_at)->format('d M Y, h:i A')],
          ['Property ID', '#'.$prop->id],
          ['Video Link', $prop->video_link ?? 'None'],
          ['Price', '₹'.number_format($prop->price).($prop->price_negotiable?' (Negotiable)':'')],
          ['Maintenance', $prop->maintenance ? '₹'.number_format($prop->maintenance).'/mo' : '—'],
          ['Security Deposit', $prop->security_deposit ? '₹'.number_format($prop->security_deposit) : '—'],
        ] as $info)
        <div class="d-flex justify-content-between align-items-start mb-2 pb-2" style="border-bottom:1px solid #F3F4F6;">
          <span style="font-size:12px;color:#9CA3AF;font-weight:600;">{{ $info[0] }}</span>
          <span style="font-size:13px;font-weight:600;color:#111;text-align:right;max-width:55%;">{{ $info[1] }}</span>
        </div>
        @endforeach
      </div>
    </div>

  </div>
</div>
</section>

{{-- Reject Modal --}}
<div class="modal fade" id="rejectModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" style="border-radius:16px;">
      <div class="modal-header border-0"><h5 class="modal-title" style="font-weight:800;">Reject Property</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <div class="p-3 rounded mb-3" style="background:#FFF1F3;border:1px solid #FECDD3;font-size:13px;color:#BE123C;" id="rejectPropTitle"></div>
        <label style="font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;">Reason <span style="color:#e30620;">*</span></label>
        <textarea class="form-control mt-1" id="rejectReason" rows="3" placeholder="Explain why this property is rejected…" style="border-radius:10px;font-size:13px;"></textarea>
      </div>
      <div class="modal-footer border-0">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-danger" id="confirmRejectBtn" style="border-radius:10px;"><i class="bi bi-x-circle-fill me-1"></i> Confirm Rejection</button>
      </div>
    </div>
  </div>
</div>
@endsection

@section('script')
<script>
let rejectPropId = null;

async function approveProperty(id) {
  if (!confirm('Approve and publish this property?')) return;
  const res = await fetch('{{ url("property-approval/approve") }}', {
    method:'POST',
    headers:{'Content-Type':'application/json','X-CSRF-TOKEN':'{{ csrf_token() }}','Accept':'application/json'},
    body: JSON.stringify({id})
  });
  const data = await res.json();
  if (!data.error) {
    toastr.success(data.message);
    setTimeout(()=>window.location.href='{{ url("property-approval") }}', 1500);
  } else toastr.error(data.message);
}

function openRejectModal(id, title) {
  rejectPropId = id;
  document.getElementById('rejectPropTitle').textContent = title;
  document.getElementById('rejectReason').value = '';
  new bootstrap.Modal(document.getElementById('rejectModal')).show();
}

document.getElementById('confirmRejectBtn').addEventListener('click', async function() {
  const reason = document.getElementById('rejectReason').value.trim();
  if (!reason) { toastr.warning('Please provide a rejection reason.'); return; }
  this.innerHTML = '<i class="bi bi-hourglass-split me-1"></i> Rejecting…';
  this.disabled = true;
  const res = await fetch('{{ url("property-approval/reject") }}', {
    method:'POST',
    headers:{'Content-Type':'application/json','X-CSRF-TOKEN':'{{ csrf_token() }}','Accept':'application/json'},
    body: JSON.stringify({id: rejectPropId, reason})
  });
  const data = await res.json();
  this.innerHTML = '<i class="bi bi-x-circle-fill me-1"></i> Confirm Rejection';
  this.disabled = false;
  if (!data.error) {
    toastr.success(data.message);
    bootstrap.Modal.getInstance(document.getElementById('rejectModal')).hide();
    setTimeout(()=>window.location.href='{{ url("property-approval") }}', 1500);
  } else toastr.error(data.message);
});
</script>
@endsection
