@extends('layouts.main')
@section('title') Property Approval @endsection
@section('page-title')
<div class="page-title">
  <div class="row">
    <div class="col-12 col-md-6 order-md-1 order-last">
      <h4><i class="bi bi-check-square-fill me-2" style="color:#e30620;"></i>Property Approval</h4>
      <nav aria-label="breadcrumb"><ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ url('home') }}">Home</a></li>
        <li class="breadcrumb-item active">Property Approval</li>
      </ol></nav>
    </div>
  </div>
</div>
@endsection

@section('content')
<section class="section">

  {{-- Status Tabs --}}
  <div class="row mb-4 g-3">
    @foreach([
      ['pending','Pending Review',$pending,'#D97706','#FFFBEB','bi-hourglass-split'],
      ['approved','Approved',$approved,'#16A34A','#F0FDF4','bi-check-circle-fill'],
      ['rejected','Rejected',$rejected,'#E30620','#FFF1F3','bi-x-circle-fill'],
    ] as $tab)
    <div class="col-md-4">
      <div class="card border-0 tab-stat-card" data-status="{{ $tab[0] }}"
        style="border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.07);cursor:pointer;border:2px solid {{ $tab[0]==='pending'?$tab[2]:'transparent' }}!important;transition:all .2s;">
        <div class="card-body p-4">
          <div class="d-flex align-items-center justify-content-between">
            <div>
              <p class="mb-1" style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:{{ $tab[2] }};">{{ $tab[1] }}</p>
              <h3 class="mb-0" style="font-size:36px;font-weight:900;color:#111;">{{ $tab[1]==='Pending Review'?$pending:($tab[1]==='Approved'?$approved:$rejected) }}</h3>
            </div>
            <div style="width:56px;height:56px;background:{{ $tab[4] }};border-radius:16px;display:flex;align-items:center;justify-content:center;">
              <i class="bi {{ $tab[5] }}" style="font-size:26px;color:{{ $tab[3] }};"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
    @endforeach
  </div>

  {{-- Filters + Table --}}
  <div class="card border-0" style="border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.07);">
    <div class="card-header bg-white py-3" style="border-radius:16px 16px 0 0;">
      <div class="row g-2 align-items-center">
        <div class="col-md-3">
          <select class="form-select form-select-sm" id="statusFilter">
            <option value="pending">⏳ Pending Review</option>
            <option value="approved">✅ Approved</option>
            <option value="rejected">❌ Rejected</option>
            <option value="">All Properties</option>
          </select>
        </div>
        <div class="col-md-3">
          <select class="form-select form-select-sm" id="categoryFilter">
            <option value="">All Categories</option>
            @foreach($categories as $cat)
            <option value="{{ $cat->id }}">{{ $cat->category }}</option>
            @endforeach
          </select>
        </div>
      </div>
    </div>
    <div class="card-body p-0">
      <table class="table table-hover mb-0" id="approvalTable"
        data-toggle="table"
        data-url="{{ url('property-approval/list') }}"
        data-side-pagination="server"
        data-pagination="true"
        data-search="true"
        data-page-list="[10,25,50]"
        data-sort-name="created_at"
        data-sort-order="desc"
        data-query-params="approvalQueryParams"
        data-responsive="true"
        data-show-refresh="true">
        <thead style="background:#F9FAFB;">
          <tr>
            <th data-field="id" data-width="60" style="font-size:11px;font-weight:700;text-transform:uppercase;color:#6B7280;">#</th>
            <th data-field="title" data-formatter="propTitleFormatter" style="font-size:11px;font-weight:700;text-transform:uppercase;color:#6B7280;">Property</th>
            <th data-field="owner_name" data-formatter="ownerInfoFormatter" style="font-size:11px;font-weight:700;text-transform:uppercase;color:#6B7280;">Owner</th>
            <th data-field="category_name" data-align="center" style="font-size:11px;font-weight:700;text-transform:uppercase;color:#6B7280;">Category</th>
            <th data-field="propery_type" data-align="center" data-formatter="propTypeFormatter" style="font-size:11px;font-weight:700;text-transform:uppercase;color:#6B7280;">Type</th>
            <th data-field="price" data-align="right" data-formatter="priceFormatter" style="font-size:11px;font-weight:700;text-transform:uppercase;color:#6B7280;">Price</th>
            <th data-field="created_at" data-align="center" data-sortable="true" style="font-size:11px;font-weight:700;text-transform:uppercase;color:#6B7280;">Submitted</th>
            <th data-field="request_status" data-align="center" data-formatter="reqStatusFormatter" style="font-size:11px;font-weight:700;text-transform:uppercase;color:#6B7280;">Status</th>
            <th data-field="id" data-align="center" data-formatter="approvalActionFormatter" style="font-size:11px;font-weight:700;text-transform:uppercase;color:#6B7280;">Actions</th>
          </tr>
        </thead>
      </table>
    </div>
  </div>

</section>

{{-- Reject Modal --}}
<div class="modal fade" id="rejectModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" style="border-radius:16px;">
      <div class="modal-header border-0">
        <h5 class="modal-title" style="font-weight:800;">Reject Property</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <div class="p-3 rounded" style="background:#FFF1F3;border:1px solid #FECDD3;font-size:13px;color:#BE123C;" id="rejectPropTitle"></div>
        </div>
        <label style="font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:.5px;">Reason for Rejection <span style="color:#e30620;">*</span></label>
        <textarea class="form-control mt-1" id="rejectReason" rows="3" placeholder="Explain why this property is being rejected…" style="border-radius:10px;font-size:13px;"></textarea>
        <div style="font-size:11px;color:#9CA3AF;margin-top:6px;">This reason will be stored for reference. The owner can resubmit after fixing the issue.</div>
      </div>
      <div class="modal-footer border-0">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-danger" id="confirmRejectBtn" style="border-radius:10px;">
          <i class="bi bi-x-circle-fill me-1"></i> Confirm Rejection
        </button>
      </div>
    </div>
  </div>
</div>
@endsection

@section('script')
<script>
let rejectPropId = null;

function approvalQueryParams(p) {
  return {
    sort: p.sort, order: p.order, offset: p.offset, limit: p.limit, search: p.search,
    request_status: $('#statusFilter').val(),
    category_id:    $('#categoryFilter').val(),
  };
}

function propTitleFormatter(v, row) {
  var img = row.title_image
    ? `<img src="/images/property_title_img/${row.title_image}" style="width:44px;height:38px;object-fit:cover;border-radius:8px;margin-right:10px;flex-shrink:0;" onerror="this.style.display='none'">`
    : `<div style="width:44px;height:38px;background:#EEF2FF;border-radius:8px;margin-right:10px;flex-shrink:0;display:inline-flex;align-items:center;justify-content:center;"><i class="bi bi-building" style="color:#818CF8;"></i></div>`;
  return `<div style="display:flex;align-items:center;">
    ${img}
    <div>
      <div style="font-weight:700;font-size:13px;max-width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${v}</div>
      <div style="font-size:11px;color:#9CA3AF;">${row.city||''}${row.state?', '+row.state:''}</div>
    </div>
  </div>`;
}

function ownerInfoFormatter(v, row) {
  var type = row.owner_type === 'builder'
    ? `<span style="background:#EDE9FE;color:#7C3AED;padding:1px 7px;border-radius:4px;font-size:10px;font-weight:700;">Builder</span>`
    : `<span style="background:#E0F2FE;color:#0369A1;padding:1px 7px;border-radius:4px;font-size:10px;font-weight:700;">Seller</span>`;
  return `<div>
    <div style="font-weight:600;font-size:13px;">${v} ${type}</div>
    <div style="font-size:11px;color:#9CA3AF;">${row.owner_email||''}</div>
    ${row.company_name && row.company_name !== '—' ? `<div style="font-size:11px;color:#9CA3AF;">${row.company_name}</div>` : ''}
  </div>`;
}

function propTypeFormatter(v) {
  return v == 0
    ? '<span style="background:#EFF6FF;color:#2563EB;padding:3px 9px;border-radius:6px;font-size:11px;font-weight:700;">For Sale</span>'
    : '<span style="background:#FFFBEB;color:#D97706;padding:3px 9px;border-radius:6px;font-size:11px;font-weight:700;">For Rent</span>';
}

function priceFormatter(v) {
  if (!v) return '—';
  var n = parseFloat(v);
  var display = n >= 10000000 ? '₹'+(n/10000000).toFixed(2)+' Cr'
              : n >= 100000  ? '₹'+(n/100000).toFixed(2)+' L'
              : '₹'+n.toLocaleString('en-IN');
  return `<span style="font-weight:700;color:#e30620;">${display}</span>`;
}

function reqStatusFormatter(v) {
  var cfg = {
    approved: ['#DCFCE7','#16A34A','check-circle-fill','Approved'],
    pending:  ['#FEF9C3','#CA8A04','hourglass-split','Pending'],
    rejected: ['#FEE2E2','#DC2626','x-circle-fill','Rejected'],
  };
  var c = cfg[v] || ['#F3F4F6','#6B7280','circle','Unknown'];
  return `<span style="background:${c[0]};color:${c[1]};padding:4px 10px;border-radius:8px;font-size:11px;font-weight:700;">
    <i class="bi bi-${c[2]} me-1"></i>${c[3]}
  </span>`;
}

function approvalActionFormatter(v, row) {
  var detailBtn = `<a href="{{ url('property-approval') }}/${v}/detail" class="btn btn-sm btn-outline-primary" title="View Details" style="border-radius:8px;"><i class="bi bi-eye-fill"></i></a>`;
  if (row.request_status === 'pending') {
    return `<div class="d-flex gap-1 justify-content-center">
      ${detailBtn}
      <button class="btn btn-sm btn-success" onclick="approveProperty(${v},'${row.title}')" title="Approve" style="border-radius:8px;"><i class="bi bi-check-lg"></i> Approve</button>
      <button class="btn btn-sm btn-danger"  onclick="openRejectModal(${v},'${row.title}')" title="Reject" style="border-radius:8px;"><i class="bi bi-x-lg"></i> Reject</button>
    </div>`;
  }
  return `<div class="d-flex gap-1 justify-content-center">${detailBtn}</div>`;
}

async function approveProperty(id, title) {
  if (!confirm(`Approve and publish:\n"${title}"?`)) return;
  const res = await fetch('{{ url("property-approval/approve") }}', {
    method:'POST',
    headers:{'Content-Type':'application/json','X-CSRF-TOKEN':'{{ csrf_token() }}','Accept':'application/json'},
    body: JSON.stringify({id})
  });
  const data = await res.json();
  if (!data.error) {
    toastr.success(data.message);
    setTimeout(()=>$('#approvalTable').bootstrapTable('refresh'), 800);
  } else {
    toastr.error(data.message);
  }
}

function openRejectModal(id, title) {
  rejectPropId = id;
  document.getElementById('rejectPropTitle').textContent = title;
  document.getElementById('rejectReason').value = '';
  new bootstrap.Modal(document.getElementById('rejectModal')).show();
}

document.getElementById('confirmRejectBtn').addEventListener('click', async function() {
  const reason = document.getElementById('rejectReason').value.trim();
  if (!reason) { toastr.warning('Please provide a reason for rejection.'); return; }
  this.innerHTML = '<i class="bi bi-hourglass-split me-1"></i> Rejecting…';
  this.disabled = true;
  const res = await fetch('{{ url("property-approval/reject") }}', {
    method:'POST',
    headers:{'Content-Type':'application/json','X-CSRF-TOKEN':'{{ csrf_token() }}','Accept':'application/json'},
    body: JSON.stringify({id: rejectPropId, reason})
  });
  const data = await res.json();
  this.innerHTML = '<i class="bi bi-x-circle-fill me-1"></i> Confirm Rejection';
  this.disabled = false;
  if (!data.error) {
    toastr.success(data.message);
    bootstrap.Modal.getInstance(document.getElementById('rejectModal')).hide();
    setTimeout(()=>$('#approvalTable').bootstrapTable('refresh'), 800);
  } else {
    toastr.error(data.message);
  }
});

// Tab stats click
document.querySelectorAll('.tab-stat-card').forEach(card => {
  card.addEventListener('click', function() {
    document.querySelectorAll('.tab-stat-card').forEach(c => c.style.borderColor = 'transparent');
    this.style.borderColor = '#e30620';
    $('#statusFilter').val(this.dataset.status);
    $('#approvalTable').bootstrapTable('refresh');
  });
});

// Filter changes
$('#statusFilter, #categoryFilter').on('change', function() {
  $('#approvalTable').bootstrapTable('refresh');
});
</script>
@endsection
