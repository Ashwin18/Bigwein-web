<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta name="csrf-token" content="{{ csrf_token() }}"/>
<title>@yield('title','Dashboard') — BigWein Owner Portal</title>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
<link rel="stylesheet" href="{{ asset('frontend/css/owner.css') }}"/>
@stack('styles')
</head>
<body>
<div class="app" id="app">

  {{-- SIDEBAR --}}
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-logo">
      <a href="{{ url('/') }}">
        <div class="logo-img">B</div>
        <div class="logo-text">
          <span class="big">Big</span><span class="wein">Wein</span>
          <span class="logo-sub">Owner Portal</span>
        </div>
      </a>
    </div>

    @php $cust = session('bw_customer'); @endphp
    <div class="sidebar-user">
      <div class="su-inner">
        @if(!empty($cust['profile']))
          <img src="{{ asset('images/'.config('global.USER_IMG_PATH','user_img/').$cust['profile']) }}" class="su-avatar" style="object-fit:cover;" alt=""/>
        @else
          <div class="su-avatar">{{ strtoupper(substr($cust['name']??'U',0,1)) }}</div>
        @endif
        <div style="min-width:0;">
          <span class="su-name">{{ $cust['name'] ?? 'Owner' }}</span>
          <div class="su-type">
            <div class="dot"></div>
            <span>{{ $cust['owner_type'] === 'builder' ? 'Builder / Developer' : 'Seller / Owner' }}</span>
          </div>
          <div class="su-plan">{{ $activePlanName ?? 'Free Plan' }}</div>
        </div>
      </div>
    </div>

    <nav class="sidebar-nav">
      <div class="nav-section">
        <div class="nav-section-label">Main</div>
        <a href="{{ url('/owner/dashboard') }}" class="nav-item {{ request()->is('owner/dashboard') ? 'active' : '' }}">
          <i class="fa-solid fa-chart-pie"></i> Dashboard
        </a>
        <a href="{{ url('/owner/my-properties') }}" class="nav-item {{ request()->is('owner/my-properties') ? 'active' : '' }}">
          <i class="fa-solid fa-building"></i> My Properties
          @if(($propCount??0) > 0)<div class="nav-badge">{{ $propCount }}</div>@endif
        </a>
        <a href="{{ url('/owner/post-property') }}" class="nav-item {{ request()->is('owner/post-property') ? 'active' : '' }}">
          <i class="fa-solid fa-plus-circle"></i> Post Property
        </a>
      </div>
      <div class="nav-section">
        <div class="nav-section-label">Activity</div>
        <a href="{{ url('/owner/enquiries') }}" class="nav-item {{ request()->is('owner/enquiries') ? 'active' : '' }}">
          <i class="fa-solid fa-message"></i> Enquiries
          @if(($enquiryCount??0) > 0)<div class="nav-badge">{{ $enquiryCount }}</div>@endif
        </a>
      </div>
      <div class="nav-section">
        <div class="nav-section-label">Account</div>
        <a href="{{ url('/owner/subscription') }}" class="nav-item {{ request()->is('owner/subscription') ? 'active' : '' }}">
          <i class="fa-solid fa-crown"></i> Subscription
        </a>
        <a href="{{ url('/owner/profile') }}" class="nav-item {{ request()->is('owner/profile') ? 'active' : '' }}">
          <i class="fa-solid fa-user-circle"></i> My Profile
        </a>
        <a href="{{ url('/') }}" class="nav-item" target="_blank">
          <i class="fa-solid fa-globe"></i> View Website
        </a>
      </div>
    </nav>

    <div class="sidebar-bottom">
      @php $plan = $activePlanName ?? 'Free'; @endphp
      @if($plan === 'Free' || $plan === 'Free Plan')
      <div class="plan-card-mini">
        <div class="pcm-title"><i class="fa-solid fa-crown"></i> Free Plan Active</div>
        <div class="pcm-sub">Upgrade for more listings &amp; premium visibility</div>
        <a href="{{ url('/owner/subscription') }}" class="pcm-btn">Upgrade Now →</a>
      </div>
      @else
      <div class="plan-card-mini" style="background:rgba(22,163,74,.15);border-color:rgba(22,163,74,.25);">
        <div class="pcm-title" style="color:#4ADE80;"><i class="fa-solid fa-crown"></i> {{ $plan }}</div>
        <div class="pcm-sub">Your plan is active and running</div>
        <a href="{{ url('/owner/subscription') }}" class="pcm-btn" style="background:var(--green);">Manage Plan</a>
      </div>
      @endif
    </div>
  </aside>

  {{-- MAIN --}}
  <div class="main">
    <header class="topbar">
      <div class="tb-left">
        <button class="tb-btn" id="sidebarToggle" onclick="document.getElementById('sidebar').classList.toggle('open')">
          <i class="fa-solid fa-bars"></i>
        </button>
        <div>
          <div class="page-title">@yield('page-title','Dashboard')</div>
          <div class="page-bread">@yield('page-bread','Owner Portal')</div>
        </div>
      </div>
      <div class="tb-right">
        <button class="tb-btn" title="Notifications"><i class="fa-regular fa-bell"></i></button>
        <a href="{{ url('/owner/post-property') }}" class="post-btn"><i class="fa-solid fa-plus"></i> Post Free Ad</a>
        <form method="POST" action="{{ url('/owner/logout') }}" style="display:inline;">
          @csrf
          <button type="submit" class="tb-btn" title="Logout"><i class="fa-solid fa-right-from-bracket"></i></button>
        </form>
      </div>
    </header>

    <div class="content">
      {{-- Flash messages --}}
      @if(session('success'))
        <div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> {{ session('success') }}</div>
      @endif
      @if(session('error'))
        <div class="alert alert-error"><i class="fa-solid fa-circle-xmark"></i> {{ session('error') }}</div>
      @endif
      @if($errors->any())
        <div class="alert alert-error">
          <i class="fa-solid fa-triangle-exclamation"></i>
          @foreach($errors->all() as $e) {{ $e }}<br> @endforeach
        </div>
      @endif

      @yield('content')
    </div>
  </div>
</div>

{{-- Overlay for mobile sidebar --}}
<div class="sidebar-overlay" id="sidebarOverlay" onclick="document.getElementById('sidebar').classList.remove('open');this.classList.remove('show')"></div>

<div class="toast" id="toast"></div>
<script src="{{ asset('frontend/js/owner.js') }}"></script>
@stack('scripts')
</body>
</html>
